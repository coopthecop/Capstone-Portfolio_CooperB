# Bay Area Coffee Analytics Capstone ☕
Measure and model the Bay Area coffee landscape using open data. This repo ships:
- Reproducible ETL (Python) to ingest/clean data
- Feature engineering for spatial + temporal signals
- Models: inspection score prediction, cleanliness risk forecasting, and site suitability
- Streamlit dashboard to explore market map, risk monitor, and site finder

> Starter includes tiny **sample datasets** so the app runs immediately. Swap in real data via `src/data/download.py` and `src/data/*.py` once you set source URLs.

## Quickstart
```bash
# 1) Create env (conda or mamba recommended)
mamba env create -f environment.yml && mamba activate coffee-bayarea

# 2) Run the sample ETL (creates processed feature files from sample data)
python -m src.data.clean_businesses
python -m src.data.clean_inspections
python -m src.data.clean_311
python -m src.features.make_features

# 3) Train example models (on sample data)
python -m src.models.train_inspection_model
python -m src.models.score_sites

# 4) Launch the dashboard
streamlit run app/streamlit_app.py
```

## Real Data Sources (add URLs/API keys as needed)
Edit `config/datasources.json` (generated below) to point to real endpoints. Examples you can search for:
- San Francisco: **Registered/Active Business Locations**, **Restaurant/Facility Health Inspections**, **311 Service Requests** (Street & Sidewalk Cleaning)
- BART: **station exits/entries** by day/hour
- OpenStreetMap: **amenity=cafe** / **coffee_shop** (via Geofabrik California extract)
- Census/ACS: daytime population & income by block group

> Keep your API tokens (if any) in environment variables; never commit secrets.

## Repository Layout
```
coffee-bayarea-capstone/
├── data/ (empty in git; populated by scripts)
├── notebooks/ (analysis & EDA)
├── src/ (ETL, features, models, viz helpers)
├── sql/ (schemas & views for PostGIS/DuckDB)
├── app/ (Streamlit app)
└── environment.yml
```

## Notes
- This starter avoids hard-coding fragile URLs. Drop true endpoints into `config/datasources.json` and re-run ETL.
- Spatial ops use `geopandas`/`shapely`; for scale, consider PostGIS or DuckDB with spatial extensions.
- Models are deliberately simple; improve with XGBoost/LightGBM + proper CV.
- Document limitations: ridership/311 are proxies; registry coverage varies; OSM tags may be incomplete.
