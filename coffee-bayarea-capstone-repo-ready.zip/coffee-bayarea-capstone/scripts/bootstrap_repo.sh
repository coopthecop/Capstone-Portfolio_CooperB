#!/usr/bin/env bash
set -euo pipefail

REPO_NAME="Capstone-Portfolio_CooperB"
GIT_USER="${GIT_USER:-your-github-username}"
REMOTE="git@github.com:${GIT_USER}/${REPO_NAME}.git"

echo "Initializing git repo..."
git init
git branch -M main
git add .
git commit -m "Initial commit: Bay Area Coffee Analytics Capstone"
echo "Creating remote ${REMOTE} (make sure it exists on GitHub)..."
git remote add origin "${REMOTE}"
git push -u origin main

echo "Done. Visit https://github.com/${GIT_USER}/${REPO_NAME}"
