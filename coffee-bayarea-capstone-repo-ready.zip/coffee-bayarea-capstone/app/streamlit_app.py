import streamlit as st
import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
PROC = BASE / "data" / "processed"

st.set_page_config(page_title="Bay Area Coffee Analytics", layout="wide")
st.title("☕ Bay Area Coffee Analytics — Demo Dashboard")


@st.cache_data
def load_data():
    cafes = pd.read_parquet(PROC / "cafe_businesses.parquet")
    feats = pd.read_parquet(PROC / "features.parquet")
    site  = pd.read_csv(PROC / "site_scores.csv")
    return cafes, feats, site

try:
    cafes, feats, site = load_data()
    st.subheader("Market Table")    
    st.dataframe(cafes)

    st.subheader("Risk & Features")
    st.dataframe(feats[['cafe_id','business_name','competitors_500m','cleanliness_30d_200m','last_score']])

    st.subheader("Site Suitability (Demo)")
    st.dataframe(site.sort_values('suitability', ascending=False))

    st.info("This demo uses tiny sample data. Replace with real data via ETL scripts, then refresh.")
except Exception as e:
    st.error(f"Data not prepared yet: {e}")
    st.write("Run the ETL + features + model steps in README first.")
