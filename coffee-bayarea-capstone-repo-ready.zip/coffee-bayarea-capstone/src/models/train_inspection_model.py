"""Train a simple model to predict low inspection score (<85) from features."""
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.ensemble import RandomForestClassifier
import joblib

BASE = Path(__file__).resolve().parents[2]
PROC = BASE / "data" / "processed"
MODEL_DIR = BASE / "models"
MODEL_DIR.mkdir(exist_ok=True, parents=True)

def main():
    df = pd.read_parquet(PROC / "features.parquet")
    df['low_score'] = (df['last_score'].fillna(90) < 85).astype(int)
    X = df[['competitors_500m','cleanliness_30d_200m']].fillna(0)
    y = df['low_score']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42, stratify=y)
    clf = RandomForestClassifier(n_estimators=200, random_state=42)
    clf.fit(X_train, y_train)
    print(classification_report(y_test, clf.predict(X_test)))
    joblib.dump(clf, MODEL_DIR / "inspection_low_score_rf.joblib")
    print("saved", MODEL_DIR / "inspection_low_score_rf.joblib")

if __name__ == "__main__":
    main()
