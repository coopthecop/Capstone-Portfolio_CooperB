"""Compute a site suitability score using toy weights."""
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
PROC = BASE / "data" / "processed"

def main():
    df = pd.read_parquet(PROC / "features.parquet")
    # Higher is better: demand proxy missing, so use inverted risk/competition for demo
    # Normalize
    for col in ['competitors_500m','cleanliness_30d_200m']:
        mx = df[col].max() if df[col].max() > 0 else 1
        df[col+'_n'] = 1 - (df[col]/mx)
    df['suitability'] = (0.5*df['competitors_500m_n'] + 0.5*df['cleanliness_30d_200m_n'])*100
    df[['cafe_id','business_name','city','suitability']].to_csv(PROC / "site_scores.csv", index=False)
    print("wrote", PROC / "site_scores.csv")

if __name__ == "__main__":
    main()
