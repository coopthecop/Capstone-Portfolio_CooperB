"""Clean inspections to processed/inspections.parquet"""
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
RAW = BASE / "data" / "raw"
PROC = BASE / "data" / "processed"

def main():
    PROC.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(RAW / "health_inspections.csv", parse_dates=['inspection_date'])
    df.to_parquet(PROC / "inspections.parquet", index=False)
    print("wrote", PROC / "inspections.parquet")

if __name__ == "__main__":
    main()
