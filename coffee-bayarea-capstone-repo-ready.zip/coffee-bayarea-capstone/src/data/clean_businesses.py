"""Clean and standardize cafe business registry into processed/cafe_businesses.parquet."""
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
RAW = BASE / "data" / "raw"
PROC = BASE / "data" / "processed"

def main():
    PROC.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(RAW / "cafe_businesses.csv")
    # Minimal cleaning
    df['lat'] = df['latitude']
    df['lon'] = df['longitude']
    keep = ['cafe_id','business_name','city','is_active','lat','lon']
    df[keep].to_parquet(PROC / "cafe_businesses.parquet", index=False)
    print("wrote", PROC / "cafe_businesses.parquet")

if __name__ == "__main__":
    main()
