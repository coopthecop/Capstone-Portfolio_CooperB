"""Prepare BART exits to processed/bart_exits.parquet"""
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
RAW = BASE / "data" / "raw"
PROC = BASE / "data" / "processed"

def main():
    PROC.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(RAW / "bart_station_exits.csv", parse_dates=['date'])
    df.to_parquet(PROC / "bart_exits.parquet", index=False)
    print("wrote", PROC / "bart_exits.parquet")

if __name__ == "__main__":
    main()
