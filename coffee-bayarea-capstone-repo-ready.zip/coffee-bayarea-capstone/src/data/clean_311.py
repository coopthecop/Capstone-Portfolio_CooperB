"""Clean 311 cases to processed/cases_311.parquet"""
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
RAW = BASE / "data" / "raw"
PROC = BASE / "data" / "processed"

def main():
    PROC.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(RAW / "cases_311.csv", parse_dates=['created_at','closed_at'])
    df.to_parquet(PROC / "cases_311.parquet", index=False)
    print("wrote", PROC / "cases_311.parquet")

if __name__ == "__main__":
    main()
