"""Download datasets from configured URLs into data/raw.
Edit config/datasources.json with real endpoints then run:
    python -m src.data.download
"""
from pathlib import Path
import json, os, sys, requests

BASE = Path(__file__).resolve().parents[2]
RAW = BASE / "data" / "raw"
CFG = BASE / "config" / "datasources.json"

def fetch(url, out_path):
    r = requests.get(url, timeout=60)
    r.raise_for_status()
    out_path.write_bytes(r.content)

def main():
    RAW.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(CFG.read_text())
    for key, meta in cfg.items():
        url = meta.get("url", "")
        if not url or url.startswith("PUT_"):
            print(f"[skip] {key}: configure URL in config/datasources.json")
            continue
        ext = "csv" if "csv" in url else "json"
        out = RAW / f"{key}.{ext}"
        print(f"[downloading] {key} -> {out}")
        fetch(url, out)
    print("Done. Configure URLs and re-run if needed.")

if __name__ == "__main__":
    main()
