"""Generate simple features for demo:
- competitors_500m (from OSM sample)
- cleanliness_30d_200m (rolling count near each cafe)
"""
from pathlib import Path
import pandas as pd
from datetime import timedelta
from .spatial import haversine

BASE = Path(__file__).resolve().parents[2]
PROC = BASE / "data" / "processed"
RAW = BASE / "data" / "raw"

def competitors_within(df_cafes, df_osm, radius_m=500):
    counts = []
    for _, row in df_cafes.iterrows():
        cnt = 0
        for _, o in df_osm.iterrows():
            d = haversine(row['lat'], row['lon'], o['latitude'], o['longitude'])
            if d <= radius_m:
                cnt += 1
        counts.append(cnt)
    return counts

def cleanliness_pressure(df_cafes, df_311, days=30, radius_m=200):
    end_date = df_311['created_at'].max().normalize()
    start_window = end_date - pd.Timedelta(days=days)
    dfw = df_311[(df_311['created_at']>=start_window) & (df_311['created_at']<=end_date)]
    pressure = []
    for _, row in df_cafes.iterrows():
        cnt = 0
        for _, s in dfw.iterrows():
            d = haversine(row['lat'], row['lon'], s['latitude'], s['longitude'])
            if d <= radius_m:
                cnt += 1
        pressure.append(cnt)
    return pressure

def main():
    PROC.mkdir(parents=True, exist_ok=True)
    cafes = pd.read_parquet(PROC / "cafe_businesses.parquet")
    insp  = pd.read_parquet(PROC / "inspections.parquet")
    cases = pd.read_parquet(PROC / "cases_311.parquet")
    osm   = pd.read_csv(RAW / "osm_cafes.csv")
    cafes['competitors_500m'] = competitors_within(cafes, osm, 500)
    cafes['cleanliness_30d_200m'] = cleanliness_pressure(cafes, cases, 30, 200)
    # merge last inspection score per cafe
    insp_last = insp.sort_values('inspection_date').groupby('cafe_id').tail(1)[['cafe_id','score']].rename(columns={'score':'last_score'})
    feat = cafes.merge(insp_last, on='cafe_id', how='left')
    feat.to_parquet(PROC / "features.parquet", index=False)
    print("wrote", PROC / "features.parquet")

if __name__ == "__main__":
    main()
