# ☕ Bay Area Coffee Analytics — Capstone Project

**Where’s the best place to open a coffee shop in the Bay Area?**  
This project uses open datasets from San Francisco, BART, and OpenStreetMap to map the coffee market, predict inspection risks, and score neighborhoods for new café locations.

🚀 **Live Dashboard**: [Streamlit App Demo](PUT-YOUR-STREAMLIT-LINK-HERE)  
📂 **Full Code & Data**: (this repo)  
📄 **Case Study Article**: [Medium/LinkedIn Link](PUT-YOUR-ARTICLE-LINK-HERE)

---

## 🔍 Business Objective
Help coffee operators (owners, roasters, investors) decide:
1. **Where to open next**.
2. **Which existing shops are at risk** from neighborhood cleanliness or inspection issues.
3. **How to prioritize operational fixes** likely to improve health inspection scores.

**KPIs**: projected monthly transactions, inspection score forecasts, cleanliness pressure, and a site suitability score (0–100).

---

## 📊 Data Sources
- **SF Registered/Active Business Locations** (coffee NAICS filtering)  
- **SF Restaurant/Facility Health Inspections** (LIVES schema)  
- **SF 311 Service Requests** (Street & Sidewalk Cleaning subset)  
- **BART Ridership Data** (station exits as demand proxy)  
- **OpenStreetMap California Extract** (`amenity=cafe`/`coffee_shop` competitors)  
- **US Census ACS** (optional for demographics)

---

## 🛠 Tech Stack
**Languages & Libraries**: Python, Pandas, GeoPandas, Scikit-learn, Statsmodels, XGBoost, Plotly, Altair  
**Data Storage**: PostGIS or DuckDB with spatial extensions  
**Visualization**: Streamlit, Tableau (optional)  
**Other Tools**: Git, JupyterLab

---

## 📂 Repository Structure
```
coffee-bayarea-capstone/
├── data/                # empty in git; populated by ETL scripts
├── notebooks/           # analysis & EDA
├── src/                 # ETL, features, models, viz helpers
├── sql/                 # schema & spatial views
├── app/                 # Streamlit dashboard
└── environment.yml      # reproducible environment
```

---

## 📈 Methodology
1. **ETL**: Collected and cleaned business, inspection, 311, ridership, and OSM data.  
2. **Feature Engineering**:  
   - Competitor density (within 500m)  
   - Cleanliness pressure (rolling 30-day 311 cases within 200m)  
   - Demand proxy from BART exits  
3. **Modeling**:  
   - **Inspection Risk** — Random Forest to predict low scores (<85).  
   - **Cleanliness Forecasting** — SARIMAX for next-month cleanliness pressure.  
   - **Site Suitability** — Weighted score from demand, competition, and cleanliness.  
4. **Visualization**: Interactive Streamlit app with market maps, risk monitors, and site finder.

---

## 🖼 Screenshots
*(Add images or GIFs of dashboard views here)*

---

## 🚦 How to Run Locally
```bash
# Clone repo
git clone https://github.com/yourusername/coffee-bayarea-capstone.git
cd coffee-bayarea-capstone

# Create environment
mamba env create -f environment.yml && mamba activate coffee-bayarea

# Run ETL + features + models
python -m src.data.clean_businesses
python -m src.data.clean_inspections
python -m src.data.clean_311
python -m src.features.make_features
python -m src.models.train_inspection_model
python -m src.models.score_sites

# Launch dashboard
streamlit run app/streamlit_app.py
```

---

## 📌 Next Steps
- Integrate live API pulls from DataSF and BART.
- Add SHAP explainability for inspection risk model.
- Build hex-bin site suitability heatmap layer.
- Include weather/event data for demand seasonality.

---

## 👤 Author
**Your Name**  
- LinkedIn: [Your LinkedIn](PUT-LINK-HERE)  
- Portfolio: [Your Portfolio](PUT-LINK-HERE)  
