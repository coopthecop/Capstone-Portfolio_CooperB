-- SQL schema for PostGIS or DuckDB w/ spatial
-- Adjust GEOMETRY types for your engine; for DuckDB use WKB/WKT or 'GEOMETRY' with SRID.
CREATE TABLE cafe_businesses (
  cafe_id INTEGER PRIMARY KEY,
  source TEXT,
  business_name TEXT,
  naics TEXT,
  street TEXT, city TEXT, state TEXT, zip TEXT,
  latitude DOUBLE, longitude DOUBLE,
  first_seen DATE, last_seen DATE,
  is_active BOOLEAN
);

CREATE TABLE health_inspections (
  inspection_id INTEGER PRIMARY KEY,
  cafe_id INTEGER REFERENCES cafe_businesses(cafe_id),
  inspection_date DATE,
  score INTEGER,
  risk_category TEXT,
  violation_code TEXT,
  violation_description TEXT
);

CREATE TABLE cases_311 (
  case_id INTEGER PRIMARY KEY,
  created_at TIMESTAMP,
  closed_at TIMESTAMP,
  category TEXT,
  subcategory TEXT,
  status TEXT,
  latitude DOUBLE, longitude DOUBLE
);

CREATE TABLE bart_station_exits (
  station_code TEXT,
  date DATE,
  hour INTEGER,
  exits INTEGER
);

CREATE TABLE osm_cafes (
  osm_id BIGINT PRIMARY KEY,
  name TEXT,
  latitude DOUBLE, longitude DOUBLE
);
