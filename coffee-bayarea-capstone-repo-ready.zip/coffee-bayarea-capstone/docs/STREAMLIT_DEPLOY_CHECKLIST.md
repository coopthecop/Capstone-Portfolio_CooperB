# Streamlit Deploy Checklist

1) Create repo on GitHub: **Capstone-Portfolio_CooperB**
2) Push code:
   ```bash
   cd coffee-bayarea-capstone
   bash scripts/bootstrap_repo.sh
   ```
3) Deploy on Streamlit Cloud:
   - Go to https://share.streamlit.io/ and choose your repo.
   - App path: `app/streamlit_app.py`
   - Python version: 3.11
   - Add dependencies via `environment.yml` or `requirements.txt` (Streamlit supports environment.yml)
4) (Optional) Secrets:
   Add `.streamlit/secrets.toml` via Streamlit settings if you use API keys.
5) Set **Deploy** and test the app.
6) Update README links for **Live Demo** + **Case Study Article**.
